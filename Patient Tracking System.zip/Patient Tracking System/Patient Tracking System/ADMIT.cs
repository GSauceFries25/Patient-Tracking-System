﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Patient_Tracking_System
{
    public partial class ADMIT : Form
    {
        
        SqlConnection con;

        public ADMIT()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            DASH frm2 = new DASH();
            frm2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");

            con.Open();

            SqlCommand cnn = new SqlCommand("insert into PTS(NAME,DATE,SEX,AGE,CLINICAL_CASE,ROOM,ADDRESS) values(@NAME,@DATE,@SEX,@AGE,@CLINICAL_CASE,@ROOM,@ADDRESS)", con);

            cnn.Parameters.AddWithValue("@NAME", (txtname.Text));
            cnn.Parameters.AddWithValue("@DATE", (txtdate.Text));
            cnn.Parameters.AddWithValue("@SEX", (txtsex.Text));
            cnn.Parameters.AddWithValue("@AGE", int.Parse(txtage.Text));
            cnn.Parameters.AddWithValue("@CLINICAL_CASE", (txtcc.Text));
            cnn.Parameters.AddWithValue("@ROOM", (txtroom.Text));
            cnn.Parameters.AddWithValue("@ADDRESS", (txtadd.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("RECORD HAS BEEN ADMITTED SUCCESFULLY!");

            this.Hide();
            DASH frm2 = new DASH();
            frm2.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtname.Clear();
            txtdate.Clear();
            txtsex.Clear();
            txtage.Clear();
            txtcc.Clear();
            txtroom.Clear();
            txtadd.Clear();

            txtname.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");

            con.Open();

            SqlCommand cnn = new SqlCommand("Update PTS Set DATE=@DATE,SEX=@SEX,AGE=@AGE,CLINICAL_CASE=@CLINICAL_CASE,ROOM=@ROOM,ADDRESS=@ADDRESS where NAME=@NAME", con);

            cnn.Parameters.AddWithValue("@NAME", (txtname.Text));
            cnn.Parameters.AddWithValue("@DATE", (txtdate.Text));
            cnn.Parameters.AddWithValue("@SEX", (txtsex.Text));
            cnn.Parameters.AddWithValue("@AGE", int.Parse(txtage.Text));
            cnn.Parameters.AddWithValue("@CLINICAL_CASE", (txtcc.Text));
            cnn.Parameters.AddWithValue("@ROOM", (txtroom.Text));
            cnn.Parameters.AddWithValue("@ADDRESS", (txtadd.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("RECORD HAS BEEN UPDATED SUCCESFULLY!");

            this.Hide();
            DASH frm2 = new DASH();
            frm2.Show();
        }
    }
}
