﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patient_Tracking_System
{
    public partial class LOG : Form
    {
        public LOG()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((txtuser.Text.Equals("TeamPauwi")) && (txtpass.Text.Equals("uuwinathanks")))
            {
                MessageBox.Show("SUCCESFULLY LOGGED IN!");

                this.Hide();
                DASH frm2 = new DASH();
                frm2.Show();

            }
            else
            {
                MessageBox.Show("USER OR PASSWORD IS INCORRECT!");
            }
        }

        private void bttncancel_Click(object sender, EventArgs e)
        {
            txtuser.Clear();
            txtpass.Clear();

            txtuser.Focus();
        }
    }
}
