﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Patient_Tracking_System
{
    public partial class DASH : Form
    {
        SqlConnection con;

        public DASH()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SUCCESFULLY LOGGED OUT!");

            this.Hide();
            LOG frm1 = new LOG();
            frm1.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            ADMIT frm3 = new ADMIT();
            frm3.Show();

        }

        private void DASH_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");


            SqlCommand cnn = new SqlCommand("Select * from PTS", con);


            SqlDataAdapter de = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            de.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");

            con.Open();

            SqlCommand cnn = new SqlCommand("Select * from PTS where NAME=@NAME", con);

            cnn.Parameters.AddWithValue("@NAME", (txtsearch.Text));

            SqlDataAdapter de = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            de.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ADMIT frm3 = new ADMIT();
            frm3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");

            con.Open();

            SqlCommand cnn = new SqlCommand("Delete from PTS where NAME=@NAME", con);

            cnn.Parameters.AddWithValue("@NAME", (txtsearch.Text));

            cnn.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("RECORD HAS BEEN DELETED!");

            txtsearch.Clear();

            txtsearch.Focus();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\user\Documents\LALEN.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cnn = new SqlCommand("Select * from PTS", con);

            SqlDataAdapter de = new SqlDataAdapter(cnn);

            DataTable table = new DataTable();

            de.Fill(table);

            dataGridView1.DataSource = table;

            txtsearch.Clear();
          
            txtsearch.Focus();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
